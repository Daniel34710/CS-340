from pymongo import MongoClient
from bson.objectid import ObjectId

class AnimalShelter(object):
    """CRUD operations for Animal collection in MongoDB"""

    def __init__(self):
        # Connection Variables
        USER = 'aacuser'
        PASS = 'Password123'
        HOST = 'localhost'
        PORT = 27017
        DB = 'aac'
        COL = 'animals'

        # Initialize Connection
        self.client = MongoClient(
            f'mongodb://{USER}:{PASS}@{HOST}:{PORT}/{DB}'
        )

        self.database = self.client[DB]
        self.collection = self.database[COL]


    # CREATE
    def create(self, data):
        if data is not None:
            try:
                self.collection.insert_one(data)
                return True

            except Exception as e:
                print(f"Create Error: {e}")
                return False

        else:
            raise ValueError("Nothing to save, data parameter is empty")


    # READ
    def read(self, query):
        try:
            data = self.collection.find(query)
            return list(data)

        except Exception as e:
            print(f"Read Error: {e}")
            return []

    # UPDATE
    def update(self, query, new_values):
        try:
            result = self.collection.update_many(
                query,
                {"$set": new_values}
            )

            return result.modified_count

        except Exception as e:
            print(f"Update Error: {e}")
            return 0


    # DELETE
    def delete(self, query):
        try:
            result = self.collection.delete_many(query)
            return result.deleted_count

        except Exception as e:
            print(f"Delete Error: {e}")
            return 0